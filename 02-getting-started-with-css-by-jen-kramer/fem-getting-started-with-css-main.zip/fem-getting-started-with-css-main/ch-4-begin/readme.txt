NOTE:

https://gettingstartedwith.css.education/ch4.html -- instructions for chapter 4.

This set of files is what you should have after you've done the following:

Part 1:
1. On your desktop, make a folder called "portfolio". Inside of that, make a folder for images and one for CSS.

2. Open up VSCode and drag your folder into the editor. Make a HTML file for index.html in the portfolio folder. Make a blank stylesheet called styles.css and place it in the CSS folder.

Part 2:
1. From the very last CodePen we worked on, copy the CSS and paste it into the CSS file.
https://codepen.io/jen4web/pen/XWarGmo

(Remember to call your page index.html!)

2. In your index.html file, make sure you've got links to the Oxygen and Oxygen Mono Google fonts, as well as the Font Awesome 5 font pack.
https://fonts.google.com
https://fontawesome.com


3. From the appropriate CodePens, copy over your HTML, starting with the header, then the introductory text, then the contact area, and finally the footer.


Once you've done that, your site should be close to this one.