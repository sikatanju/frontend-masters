# fem-getting-started-with-css
Goes with the course "Getting Started with CSS" at Frontend Masters, recorded October 14, 2021.

Course website, including instructions, CodePen demos and exercises, and model final site are available at https://gettingstartedwith.css.education

Course videos available at https://frontendmasters.com/courses/getting-started-css/

## License: 

You are welcome to copy this repo to follow along with the course. You are welcome to use this material for personal, academic, or educational use, but not commercial use.

**Be kind and cite your sources.** Suggested:

Original files and/or code from Jen Kramer (jenkramer.org) from the "Getting Started with CSS" course at Frontend Masters (frontendmasters.com).
